#include <stdio.h>

int main()
{
int number;
for(number=0;number<10;number++)
{
printf("%d\n",number);
}
}