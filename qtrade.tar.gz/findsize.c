stuct _outs{
char key[40];
int amount;
};
