#include <stdlib.h>
#include <string.h>


char getcookie(char *key,char *value);